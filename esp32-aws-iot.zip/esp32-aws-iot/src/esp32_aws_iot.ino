/*
  ESP32 + DHT22 → AWS IoT Core (MQTT over TLS)
  Libraries: PubSubClient, DHT sensor library (Adafruit), Adafruit Unified Sensor, ArduinoJson
  Hardware:  DHT22 VCC→3.3V, GND→GND, DATA→GPIO4 (10kΩ pull-up to 3.3V)
*/

#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <DHT.h>

const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* AWS_ENDPOINT  = "xxxxxxxxxxxxxx-ats.iot.ap-south-1.amazonaws.com";
const int   AWS_PORT      = 8883;
const char* THING_NAME    = "esp32-sensor-01";
const char* MQTT_TOPIC    = "esp32/sensor/data";

// Paste certificate contents below (see certs/README.md)
const char AWS_ROOT_CA[] PROGMEM = R"EOF(
-----BEGIN CERTIFICATE-----
<PASTE AmazonRootCA1.pem CONTENT HERE>
-----END CERTIFICATE-----
)EOF";

const char DEVICE_CERT[] PROGMEM = R"EOF(
-----BEGIN CERTIFICATE-----
<PASTE xxxxxxxx-certificate.pem.crt CONTENT HERE>
-----END CERTIFICATE-----
)EOF";

const char DEVICE_KEY[] PROGMEM = R"EOF(
-----BEGIN RSA PRIVATE KEY-----
<PASTE xxxxxxxx-private.pem.key CONTENT HERE>
-----END RSA PRIVATE KEY-----
)EOF";

#define DHT_PIN  4
#define DHT_TYPE DHT22
DHT dht(DHT_PIN, DHT_TYPE);

WiFiClientSecure net;
PubSubClient     client(net);
unsigned long    lastPublish = 0;
const long       PUBLISH_INTERVAL = 10000;

void connectWiFi() {
  Serial.print("Connecting to WiFi");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print("."); }
  Serial.println("\nWiFi connected: " + WiFi.localIP().toString());
}

void messageReceived(char* topic, byte* payload, unsigned int length) {
  String msg = "";
  for (unsigned int i = 0; i < length; i++) msg += (char)payload[i];
  Serial.println("Received [" + String(topic) + "]: " + msg);
}

void connectAWS() {
  net.setCACert(AWS_ROOT_CA);
  net.setCertificate(DEVICE_CERT);
  net.setPrivateKey(DEVICE_KEY);
  client.setServer(AWS_ENDPOINT, AWS_PORT);
  client.setCallback(messageReceived);
  Serial.print("Connecting to AWS IoT Core");
  while (!client.connect(THING_NAME)) { Serial.print("."); delay(1000); }
  Serial.println("\nConnected!");
  client.subscribe("esp32/sensor/command");
}

void publishSensorData() {
  float temp = dht.readTemperature();
  float hum  = dht.readHumidity();
  if (isnan(temp) || isnan(hum)) { Serial.println("Sensor read error!"); return; }

  StaticJsonDocument<200> doc;
  doc["device_id"]   = THING_NAME;
  doc["temperature"] = round(temp * 10.0) / 10.0;
  doc["humidity"]    = round(hum  * 10.0) / 10.0;
  doc["unit"]        = "celsius";
  doc["timestamp"]   = millis();

  char payload[200];
  serializeJson(doc, payload);
  Serial.println("Publishing: " + String(payload));
  client.publish(MQTT_TOPIC, payload)
    ? Serial.println("OK") : Serial.println("FAILED");
}

void setup() {
  Serial.begin(115200);
  dht.begin();
  connectWiFi();
  connectAWS();
}

void loop() {
  if (!client.connected()) connectAWS();
  client.loop();
  if (millis() - lastPublish >= PUBLISH_INTERVAL) {
    lastPublish = millis();
    publishSensorData();
  }
}
