# Certificates

**Do NOT commit real certificates here. They are in .gitignore.**

Place these 3 files here after downloading from AWS IoT Core:

| File | Source |
|------|--------|
| `AmazonRootCA1.pem` | Download from AWS (Root CA) |
| `xxxxxxxx-certificate.pem.crt` | Your Thing certificate |
| `xxxxxxxx-private.pem.key` | Your Thing private key |

Then paste the contents into the matching sections in `src/esp32_aws_iot.ino`.

## How to get them
1. AWS Console → IoT Core → Manage → Things → Create thing
2. Choose "Auto-generate certificate"
3. Download all 3 files before closing the dialog (you cannot re-download the key)
