# ESP32 + DHT22 → AWS IoT Core

Send temperature and humidity sensor data from an ESP32 to AWS IoT Core over MQTT (TLS), then store it in DynamoDB and monitor via CloudWatch.

## Architecture

```
DHT22 Sensor
     │
     ▼
  ESP32                WiFi / TLS (port 8883)
  (MQTT client) ──────────────────────────► AWS IoT Core
                                                  │
                                         IoT Rule │
                                    ┌─────────────┴──────────────┐
                                    ▼                            ▼
                               DynamoDB                    CloudWatch
                           (store readings)              (monitor + alerts)
```

## Hardware

| Component | Connection |
|-----------|-----------|
| DHT22 VCC | ESP32 3.3V |
| DHT22 GND | ESP32 GND |
| DHT22 DATA | ESP32 GPIO4 |
| 10kΩ resistor | Between VCC and DATA |

## Setup

### 1. AWS IoT Core
1. Create a **Thing** named `esp32-sensor-01`
2. Auto-generate certificates — download all 3 files
3. Create and attach a **Policy** (see `docs/aws-policy.json`)
4. Copy your **Device data endpoint** from IoT Core → Settings

### 2. Arduino IDE
Install these libraries via **Sketch → Include Library → Manage Libraries**:
- `PubSubClient` by Nick O'Leary
- `DHT sensor library` by Adafruit
- `Adafruit Unified Sensor`
- `ArduinoJson` by Benoit Blanchon

Add ESP32 board support:
```
https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
```

### 3. Configure the sketch
Open `src/esp32_aws_iot.ino` and fill in:
```cpp
const char* WIFI_SSID     = "your_wifi";
const char* WIFI_PASSWORD = "your_password";
const char* AWS_ENDPOINT  = "xxxxxx-ats.iot.ap-south-1.amazonaws.com";
```
Paste your 3 certificate file contents into the matching `PROGMEM` string blocks.

### 4. Flash & verify
- Board: `ESP32 Dev Module`
- Upload speed: `115200`
- Open Serial Monitor at **115200 baud**

Expected output:
```
=== ESP32 AWS IoT Sensor ===
WiFi connected: 192.168.x.x
Connected to AWS IoT Core!
Publishing: {"device_id":"esp32-sensor-01","temperature":28.5,"humidity":62.3,"unit":"celsius","timestamp":12045}
OK
```

### 5. Verify in AWS
IoT Core → **MQTT Test Client** → Subscribe to `esp32/sensor/data`

## MQTT Topics

| Topic | Direction | Purpose |
|-------|-----------|---------|
| `esp32/sensor/data` | ESP32 → AWS | Publish sensor readings |
| `esp32/sensor/command` | AWS → ESP32 | Send remote commands |

## Sample Payload

```json
{
  "device_id": "esp32-sensor-01",
  "temperature": 28.5,
  "humidity": 62.3,
  "unit": "celsius",
  "timestamp": 12045
}
```

## DynamoDB Setup

1. Create table: `esp32-sensor-data`
   - Partition key: `device_id` (String)
   - Sort key: `timestamp` (Number)
2. IoT Core → Message Routing → Rules → Create rule
   - Query: `SELECT * FROM 'esp32/sensor/data'`
   - Action: DynamoDB → select your table

## Security Notes

- **Never commit your `.pem` or `.key` files** — they are in `.gitignore`
- Use least-privilege IAM policies in production
- Replace `millis()` timestamp with NTP time for real deployments

## License

MIT
