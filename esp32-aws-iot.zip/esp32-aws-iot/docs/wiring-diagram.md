# Wiring Diagram

```
ESP32                    DHT22
─────                    ─────
3.3V ──────────────────► VCC
GND  ──────────────────► GND
GPIO4 ─────────────────► DATA
                          │
                         10kΩ
                          │
3.3V ───────────────────┘
```

## Notes
- The 10kΩ pull-up resistor is required for reliable DHT22 readings
- Keep the wire between GPIO4 and DATA short (under 20cm ideally)
- DHT22 minimum sampling interval is 2 seconds
